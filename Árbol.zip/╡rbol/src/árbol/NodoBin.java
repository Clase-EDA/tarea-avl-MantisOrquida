/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package árbol;

/**
 *
 * @author 165473
 */
public class NodoBin<T extends Comparable<T>> {
    private T elem;
    private NodoBin<T> izq, der, padre;
    private int fe;
    
    NodoBin(T e){
        elem = e;
        izq = null;
        der = null;
        fe = 0;
//        cuelga(self);
    }

    public int getFe() {
        return fe;
    }

    public void setFe(int fe) {
        this.fe = fe;
    }
    
    

    public void setPadre(NodoBin<T> padre) {
        this.padre = padre;
    }

    public void setElem(T elem) {
        this.elem = elem;
    }

    public void setIzq(NodoBin<T> izq) {
        this.izq = izq;
    }

    public void setDer(NodoBin<T> der) {
        this.der = der;
    }
    
    
    
    public void  cuelga(NodoBin<T> n){
        if (n == null)
            return;
        if (n.getElem() == null){            
        }
        else if (n.getElem().compareTo(elem) < 0){
            izq = n;
            izq.setPadre(n);
        }
        else{
            der = n;
            der.setPadre(n);
        }        
    }

    public T getElem() {
        return elem;
    }

    public NodoBin<T> getIzq() {
        return izq;
    }

    public NodoBin<T> getDer() {
        return der;
    }

    public NodoBin<T> getPadre() {
        return padre;
    }
    
    
    
//    public int NumDescendiente(){     //Cuenta cuántos descendientes tiene un nodo.
//        if (izq == null && der == null) //Mi alternativa
//            return 0;
//        else{
//            if (izq != null){            
//                return izq.NumDescendiente() + 1;
//            }                    
//            if (der != null){
//                return der.NumDescendiente() + 1;
//            }
//        }
//    }
    
    public int numDescendientes(){
        int res = 0;
        if (izq != null)
            res = izq.numDescendientes() + 1;
        if (der != null)
            res += der.numDescendientes() + 1;
        return res;
    }
    
    public int numHijosDirectos(){
        int cont = 0;
        if (izq != null)
            cont++;
        if (der != null)
            cont++;
        return cont;
    }
}
