/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package árbol;

import java.util.ArrayList;

/**
 *
 * @author 165473
 * @param <T>
 */
public interface ColaADT<T> {
    public void agrega(T dato);
    public T elimina();
    public boolean estáVacía();
    public T conPrim();
    public int cuentaElementos();
    public T consultaUltimo();
    public ArrayList<T> multiQuita(int n);
}
