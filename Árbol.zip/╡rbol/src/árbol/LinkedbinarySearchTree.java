/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package árbol;

import java.util.ArrayList;
import java.util.Stack;
import java.util.*;
/**
 *
 * @author 165473
 */
public class LinkedbinarySearchTree<T extends Comparable<T>> extends LinkedBinaryTree<T> implements BinarySearchTreeADT<T> {

    public LinkedbinarySearchTree(NodoBin<T> raíz) {
        super(raíz);
    }

    
    
    public NodoBin<T> busca(T elem){
        if (elem == null){
            throw new NullPointerException();
        }
        NodoBin<T> actual = raíz.getDer();
        while (actual != null && elem != actual.getElem()){
            if (elem.compareTo(actual.getElem()) < 0)
                actual = actual.getIzq();
            else
                actual = actual.getDer();
        }
        return actual;
    }
    
    private NodoBin<T> sucesorInorden(NodoBin<T> nodo){
        nodo = nodo.getDer();
        while (nodo != null){
            nodo = nodo.getIzq();
        }
        return nodo;
    }
    
    public void eliminaR(T elem){
        NodoBin<T> nodo = busca(elem);
        if (busca(elem).getElem() == null){
            return;
        }
        
        if (nodo.getDer() == null && nodo.getIzq() == null){
            if (nodo.getPadre().getIzq() == nodo){
                nodo.getPadre().setIzq(null);
            }
            else{
                nodo.getPadre().setDer(null);
            }                
        }    
        else if (nodo.getIzq() == null || nodo.getDer() == null){
            if (nodo.getIzq() != null && nodo.getDer() == null){
                nodo.getPadre().cuelga(nodo.getIzq());
                cont--;
            }
            else if (nodo.getIzq() == null){
                nodo.getPadre().cuelga(nodo.getDer());
                cont--;
            }            
        }
        else{                  
            NodoBin<T> nodo2 = nodo.getDer();                
            while (nodo2.getIzq() != null){
                nodo2 = nodo2.getIzq();
            }
            if (nodo2.getPadre() == nodo){
                nodo2.getPadre().setDer(nodo2.getDer());
                if (nodo2.getDer() != null){
                    nodo2.getDer().setPadre(nodo);
                }                
            }
            else{
                nodo2.getPadre().setIzq(nodo2.getDer());
                if (nodo2.getDer() != null){
                    nodo2.getDer().setPadre(nodo2.getPadre());
                }                
            }
            nodo2.setPadre(null);
            nodo2.setDer(null);
            nodo.setElem(nodo2.getElem());
//            nodo2 = null;
            cont--;
        }        
    }

    public void elimina(T elem){
        NodoBin<T> actual = busca(elem);
        if (actual == null)
            return;
        if (cont == 1){
            raíz = null;
            cont = 0;
            return;
        }
        if (actual.getIzq() == null && actual.getDer() == null){
            if (actual.getPadre().getIzq() == actual)
                actual.getPadre().setIzq(null);
            else
                actual.getPadre().setDer(null);
            cont--;
            return;
        }
    }
    
    @Override
    public T buscaMin(){
        NodoBin<T> actual = raíz;
        if (raíz == null)
            return null; // Excepción
        while (actual.getIzq() != null)
            actual = actual.getIzq();
        return actual.getElem();
    }
    
    @Override
    public void inserta(T elem){      
        NodoBin<T> actual, nuevo = new NodoBin(elem), papa;
        
        if (raíz.getDer() == null){
            raíz.setDer(nuevo);
            cont++;
            return;
        }
        actual = raíz.getDer();
        papa = actual;
        while (actual != null){
            papa = actual;
            if (elem.compareTo(actual.getElem()) < 0)
                actual = actual.getIzq();
            else
                actual = actual.getDer();            
        }
        papa.cuelga(nuevo);                
        nuevo.setPadre(papa);                
    }
    
    private NodoBin<T> insertaR(NodoBin<T> actual, T elem){
        if (actual == null)
            return new NodoBin(elem);
        if (elem.compareTo(actual.getElem()) < 0)
            actual.cuelga(insertaR(actual.getIzq(),elem));
        else
            actual.cuelga(insertaR(actual.getDer(),elem));
        return actual;
    }                   
    
    public int altura(NodoBin<T> actual){
        if (actual == null){
            return 0;
        }
        int izq, der;
        izq = altura(actual.getIzq()) + 1;
        der = altura(actual.getDer()) + 1;
        return Math.max(der, izq);
    }
    
    public int maxFe(){
        return maxFe(raíz.getDer());
    }
    
    private int maxFe(NodoBin<T> actual){
        if (actual == null){
            return 0;
        }
        int fe;
        fe = Math.abs(altura(actual.getDer()) - altura(actual.getIzq()));        
        return Math.max(fe, Math.max(maxFe(actual.getDer()),maxFe(actual.getIzq())));
    }
    
    public NodoBin<T> nodoMaxFe(){
        return nodoMaxFe(raíz.getDer(),0,null);
    }
    
    private NodoBin<T> nodoMaxFe(NodoBin<T> actual, int fe, NodoBin<T> res){
        if (actual != null){
            NodoBin<T> der, izq;
            fe = Math.abs(altura(actual.getDer()) - altura(actual.getIzq()));
            if (actual.getDer() != null){
                nodoMaxFe(actual.getDer(),fe,res);
            }
            if (actual.getIzq() != null){
                nodoMaxFe(actual.getIzq(),fe,res);
            }
            res = 
        }
        
        
//        if (actual == null){
//            return 0;
//        }
//        int fe;
//        fe = Math.abs(altura(actual.getDer()) - altura(actual.getIzq()));        
//        return Math.max(fe, Math.max(maxFe(actual.getDer()),maxFe(actual.getIzq())));
    }
    
    public NodoBin<T> primerAncestro(T uno, T dos){
        return primerAncestro(busca(uno),busca(dos));
    }
    
    private NodoBin<T> primerAncestro(NodoBin<T> uno, NodoBin<T> dos){
        NodoBin<T> aux = uno;
        int izq = 0, der = 0;
        while(aux != dos && aux != raíz){
            aux = aux.getPadre();
            izq++;
        }
        if (aux == dos){
            return dos;
        }
        aux = dos;
        while(aux != uno && aux != raíz){
            aux = aux.getPadre();
            der++;
        }
        if (aux == uno){
            return uno;
        }
        if (izq < der){
            return unoPorUno(uno.getPadre(),dos,uno.getPadre());
        }
        else{
            return unoPorUno(dos.getPadre(),uno,dos.getPadre());
        }
    }
    
    public NodoBin<T> unoPorUno(NodoBin<T> buscador, NodoBin<T> búsqueda, NodoBin<T> cazador){
        if (cazador == búsqueda){
            return buscador;
        }
        else if (cazador == null){
            return unoPorUno(buscador.getPadre(), búsqueda, buscador.getPadre());
        }
        else{
            if (búsqueda.getElem().compareTo(buscador.getElem()) < 0){
                return unoPorUno(buscador, búsqueda, buscador.getDer());
            }
            else{
                return unoPorUno(buscador, búsqueda, buscador.getIzq());
            }
        }
    }
    public T mediana(){        //corrige el contador y que regrese int para ayudarte
        if (cont % 2 == 0){
            return medianaPar(raíz,0,null);
        }
        else{
            return medianaImpar(raíz,0);
        }        
    }
    
    private T medianaImpar(NodoBin<T> actual, int i){
        T resul = null;
        if (actual == null){            
        }   
        else{
            medianaImpar(actual.getIzq(),i + 1);
            if (i == cont / 2){
                resul = actual.getElem();
            }
            else{
                medianaImpar(actual.getDer(),i + 1);                
            }
        }
        return resul;
    }
    
    private T medianaPar(NodoBin<T> actual, int i, T der){
        double resul;
        if (actual == null){            
        }      
        else{
            medianaPar(actual.getIzq(),i + 1,der);
            if (i == cont / 2){
                der = actual.getElem();
            }
            else if (i == cont / 2 + 1){     
                if (actual.getElem() instanceof Double && der instanceof Double){
                    resul = ((Double) actual.getElem() + (Double) der)/2;
                }
            }
            medianaPar(actual.getDer(),i + 1,der);                
        }
        return resul;
    }

    private NodoBin<T> diferencia(NodoBin<T> actual){
        if (actual == null){
            return actual;
        }
        NodoBin<T> izq, der;
        int izqA, izqB, derA, derB;
        izq = diferencia(actual.getIzq());
        izqA = altura(izq);
        izqB = al
        der = diferencia(actual.getDer());
        derA = altura(der);
        if 
    }
    
    
    
    @Override
    public T buscaMax() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public T borraMin() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public T borraMax() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public static void main(String[] args) {
//        LinkedbinarySearchTree<Integer> este = new LinkedbinarySearchTree(new NodoBin(null));
//        
//        este.inserta(70);
//        este.inserta(50);
//        este.inserta(90);
//        este.inserta(40);
//        este.inserta(60);
//        este.inserta(80);
//        este.inserta(75);
//        este.inserta(72);
//        este.inserta(73);
//        este.inserta(100);        
//        este.inserta(110);
//        este.inserta(30);
//        System.out.println(este.raíz.getElem());
//        System.out.println(este.postOrden());
//        este.eliminaR(50);       
//        System.out.println(este.postOrden());
//        este.eliminaR(70);
//        System.out.println(este.postOrden());
//        este.eliminaR(72);
//        System.out.println(este.postOrden());
//        este.eliminaR(73);
//        System.out.println(este.postOrden());
//        este.eliminaR(75);
//        System.out.println(este.postOrden());
        
//        LinkedbinarySearchTree<Integer> hoy = new LinkedbinarySearchTree(new NodoBin(null));
//        
//        hoy.inserta(100);
//        hoy.inserta(40);
//        hoy.inserta(180);
//        hoy.inserta(190);
//        System.out.println(hoy.postOrden());
//        hoy.eliminaR(100);
//        System.out.println(hoy.postOrden());
//        
//        LinkedbinarySearchTree<Integer> otro = new LinkedbinarySearchTree(new NodoBin(null));
//        
//        otro.inserta(100);
//        otro.inserta(40);
//        otro.inserta(180);
//        otro.inserta(190);
//        otro.inserta(170);
//        otro.inserta(175);
//        System.out.println(otro.postOrden());
//        System.out.println(otro.nivelOrden());
//        otro.eliminaR(100);
//        System.out.println(otro.postOrden());
        
        LinkedbinarySearchTree<Integer> antro = new LinkedbinarySearchTree(new NodoBin(null));
        
        antro.inserta(100);
        antro.inserta(120);
        antro.inserta(140);
        antro.inserta(110);
        antro.inserta(105);
        antro.inserta(80);
        antro.inserta(70);
        antro.inserta(104);
        System.out.println(antro.maxFe());
        System.out.println(antro.primerAncestro(104,140));
    }
    

}
