/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package árbol;

/**
 *
 * @author hca
 */
public interface BinarySearchTreeADT<T extends Comparable<T>> extends BinaryTreeADT<T> {
    public void inserta(T elem);
//    public T busca(T elem);
    public T buscaMin();
    public T buscaMax();
    public T borraMin();
    public T borraMax();
}
