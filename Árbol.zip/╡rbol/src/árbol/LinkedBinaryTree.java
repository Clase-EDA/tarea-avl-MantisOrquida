/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package árbol;

import colas.ColaA;
import colas.ColaADT;
import java.util.ArrayList;
import java.util.Stack;
import java.util.Iterator;

/**
 *
 * @author 165473
 */
public class LinkedBinaryTree<T extends Comparable<T>> implements BinaryTreeADT<T> {
    NodoBin<T> raíz;
    int cont;

    public LinkedBinaryTree(NodoBin<T> raíz) {
        this.raíz = raíz;
    }
    
    
    
    public boolean isEmpty(){
        return cont != 0;
    }

    public NodoBin<T> getRaíz() {
        return raíz;
    }
    
    
    
    public int size(){

        return cont;
    }
    
    @Override
    public Iterator<T> inOrden(){
        ArrayList<T> lista = new ArrayList();
        inOrden(raíz,lista);
        return lista.iterator();
    }
    
    private void inOrden(NodoBin<T> actual, ArrayList<T> lista){
        if (actual == null)
            return;
        inOrden(actual.getIzq(),lista);
        lista.add(actual.getElem());
        inOrden(actual.getDer(),lista);        
    }
    
    @Override
    public Iterator<T> preOrden(){
       return preOrden(raíz,new ArrayList()); 
    }
    
    private Iterator<T> preOrden(NodoBin<T> actual, ArrayList<T> lista){
        if (actual == null){         
        }
        else{            
        lista.add(actual.getElem());
        preOrden(actual.getIzq(),lista);        
        preOrden(actual.getDer(),lista);
        }
        return (Iterator<T>) lista.iterator();
    }
    
    @Override
    public ArrayList<T> postOrden(){
       return postOrden(raíz.getDer(),new ArrayList()); 
    }
    
    public ArrayList<Integer> postOrdenFe(){
       return postOrdenFe(raíz.getDer(),new ArrayList()); 
    }
    
    private ArrayList<T> postOrden(NodoBin<T> actual, ArrayList<T> lista){
        if (actual == null){            
        }            
        else{                    
            postOrden(actual.getIzq(),lista);        
            postOrden(actual.getDer(),lista);
            lista.add(actual.getElem());
        }
        return  lista;
    }
    
    private ArrayList<Integer> postOrdenFe(NodoBin<T> actual, ArrayList<Integer> lista){
        if (actual == null){            
        }            
        else{                    
            postOrdenFe(actual.getIzq(),lista);        
            postOrdenFe(actual.getDer(),lista);
            lista.add(actual.getFe());
        }
        return  lista;
    }
    
    public Iterator<T> preOrdenIt(){
        
        Stack<NodoBin<T>> s = new Stack();
        ArrayList<T> lista = new ArrayList();
        
        s.push(raíz);
        NodoBin<T> e = raíz;
        while (!s.isEmpty()){
            lista.add(e.getElem());
            if (e.getDer()!= null)
                s.push(e.getDer());
            if (e.getIzq() != null)
                s.push(e.getIzq());
        }
        return (Iterator<T>) lista.iterator();
        }
    
    
    @Override
    public ArrayList<T> nivelOrden(){
        
        ColaADT<NodoBin<T>> s = new ColaA();
        ArrayList<T> lista = new ArrayList();        
        NodoBin<T> e;
        
        s.agrega(raíz.getDer());
        while (!s.estáVacía()){            
            e = s.elimina();
            lista.add(e.getElem()); 
            if (e.getIzq() != null)
                s.agrega(e.getIzq());
            if (e.getDer()!= null)
                s.agrega(e.getDer());                                    
        }
        return lista;
    }

    @Override
    public boolean contains(T elem) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public T find(T elem) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

