/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package árbol;

/**
 *
 * @author 165473
 * @param <T>
 */
public class AVLTree<T extends Comparable<T>> extends LinkedbinarySearchTree<T> implements BinarySearchTreeADT<T>{

    public AVLTree(NodoBin<T> raíz) {
        super(raíz);
    }    
    
    @Override
    public void inserta(T elem){
        if (elem == null){
            throw new NullPointerException();
        }
        NodoBin<T> nuevo = new NodoBin(elem), actual, padre;
        boolean bandera;
        if (cont == 0){
            raíz.setDer(nuevo);
            nuevo.setPadre(raíz);
            cont++;            
        }
        else{
            actual = raíz.getDer();
            padre = actual;
            bandera = true;                     
            while(actual != null){
                padre = actual;                
                if (elem.compareTo(actual.getElem()) < 0){
                    actual = actual.getIzq();
                    bandera = false;
                }
                else{
                    actual = actual.getDer();
                    bandera = true;
                }
            }
            if (bandera){
                padre.setDer(nuevo);                
            }
            else{
                padre.setIzq(nuevo);                
            }
            nuevo.setPadre(padre);            
            cont++;            
            boolean fin = false;
            actual = nuevo;
            while(!fin){
                if(actual.getPadre() == raíz){
                    fin = true;     
                }
                else{
                    padre = actual.getPadre();
                    if (actual == padre.getIzq()){
                        padre.setFe(padre.getFe() - 1);
                    }
                    else{
                        padre.setFe(padre.getFe() + 1);
                    }
                    if (Math.abs(padre.getFe()) > 1){
                        padre = rotar(padre);
                        fin = true;
                    }                    
                }
                if (padre.getFe() == 0){
                        fin = true;
                }
                actual = actual.getPadre();
            }            
        }
    }
    
    public void actualizaFe(NodoBin<T> actual){                    
        boolean fin = false;
        int fE;
        
        while(!fin){
            if(actual == raíz){
                fin = true;     
            }
            else{                
                fE = altura(actual.getDer()) - altura(actual.getIzq());
                if (fE != actual.getFe()){
                    actual.setFe(fE);
                }                
                else{
                    fin = true;
                }
                if (Math.abs(actual.getFe()) > 1){
                    rotar(actual);
                    fin = true;
                }                    
            }            
            actual = actual.getPadre();
        }
    }
    
    public NodoBin<T> rotar(NodoBin<T> actual){
        if (actual.getFe() == -2){            
            if (actual.getIzq().getFe() <= 0){                
                return rotarII(actual);               
            }
            else{                
                return rotarID(actual);
            }
        }
        else{
            if (actual.getDer().getFe() >= 0){                
                return rotarDD(actual);
            }
            else{                
                return rotarDI(actual);
            }
        }
    }
    
    private NodoBin<T> rotarII(NodoBin<T> actual){        
        if (actual.getIzq().getDer() != null){
            actual.getIzq().getDer().setPadre(actual);
        }
        if (actual == actual.getPadre().getDer()){
            actual.getPadre().setDer(actual.getIzq());
        }
        else{
            actual.getPadre().setIzq(actual.getIzq());
        }
        actual.getIzq().setPadre(actual.getPadre());
        actual.setPadre(actual.getIzq());
        actual.setIzq(actual.getPadre().getDer());
        actual.getPadre().setDer(actual);        
        actual.getPadre().setFe(altura(actual) - altura(actual.getPadre().getIzq()));
        actual.setFe(altura(actual.getDer()) - altura(actual.getIzq()));            
        return actual.getPadre();
    }
    
    private NodoBin<T> rotarDD(NodoBin<T> actual){
        if (actual.getDer().getIzq() != null){
            actual.getDer().getIzq().setPadre(actual);
        }
        if (actual == actual.getPadre().getDer()){
            actual.getPadre().setDer(actual.getDer());
        }
        else{
            actual.getPadre().setIzq(actual.getDer());
        }
        actual.getDer().setPadre(actual.getPadre());
        actual.setPadre(actual.getDer());
        actual.setDer(actual.getPadre().getIzq());
        actual.getPadre().setIzq(actual);        
        actual.getPadre().setFe(altura(actual.getPadre().getDer()) - altura(actual));
        actual.setFe(altura(actual.getDer()) - altura(actual.getIzq()));        
        return actual.getPadre();
    }
    
    private NodoBin<T> rotarID(NodoBin<T> actual){
        NodoBin<T> gama = actual.getIzq().getDer();
        int a, b;
        actual.getIzq().setDer(gama.getIzq());
        if (gama.getIzq() != null){
            gama.getIzq().setPadre(actual.getIzq());
        }        
        actual.setIzq(gama.getDer());
        if (gama.getDer() != null){
            actual.getIzq().setPadre(actual);
        }
        gama.getPadre().setPadre(gama);
        gama.setIzq(gama.getPadre());
        gama.setPadre(actual.getPadre());
        if (actual == actual.getPadre().getDer()){
            actual.getPadre().setDer(gama);
        }
        else{
            actual.getPadre().setIzq(gama);
        }
        actual.setPadre(gama);
        gama.setDer(actual);
        gama.setFe(altura(gama.getDer()) - altura(gama.getIzq()));
        gama.getDer().setFe(altura(gama.getDer().getDer()) - altura(gama.getDer().getIzq()));
        gama.getIzq().setFe(altura(gama.getIzq().getDer()) - altura(gama.getIzq().getIzq()));
        /*
        a = altura(gama.getDer().getIzq());
        b = gama.getDer().getFe();
        gama.getDer().setFe(b - 3 - a);
        a = a - b + 2; 
        gama.getIzq().setFe(a - b + 3);
        gama.setFe(b - 2*a - 4);        
        */
        return gama;
    }        
    
    private NodoBin<T> rotarDI(NodoBin<T> actual){
        NodoBin<T> gama = actual.getDer().getIzq();
        int a, b;
        actual.getDer().setIzq(gama.getDer());
        if (gama.getDer() != null){
            gama.getDer().setPadre(actual.getDer());
        }
        actual.setDer(gama.getIzq());
        if (gama.getIzq() != null){
            actual.getDer().setPadre(actual);
        }
        gama.getPadre().setPadre(gama);
        gama.setDer(gama.getPadre());
        gama.setPadre(actual.getPadre());
        if (actual == actual.getPadre().getDer()){
            actual.getPadre().setDer(gama);
        }
        else{
            actual.getPadre().setIzq(gama);
        }
        actual.setPadre(gama);
        gama.setIzq(actual);
        gama.setFe(altura(gama.getDer()) - altura(gama.getIzq()));
        gama.getDer().setFe(altura(gama.getDer().getDer()) - altura(gama.getDer().getIzq()));
        gama.getIzq().setFe(altura(gama.getIzq().getDer()) - altura(gama.getIzq().getIzq()));
        /*
        a = altura(gama.getDer().getIzq());
        b = gama.getDer().getFe();
        gama.getDer().setFe(b - 3 - a);
        a = a - b + 2;
        gama.getIzq().setFe(a - b + 3);
        gama.setFe(b - 2*a - 4);
        */
        return gama;
    }
    
    @Override
    public void eliminaR(T elem){        
        NodoBin<T> nodo = busca(elem), aux;
        if (nodo.getElem() == null){
            return;
        }        
        if (nodo.getDer() == null && nodo.getIzq() == null){
            aux = nodo.getPadre();
            if (aux.getIzq() == nodo){                
                aux.setIzq(null);
            }
            else{                
                aux.setDer(null);                
            }                
            nodo.setPadre(null);            
            actualizaFe(aux);            
        }    
        else if (nodo.getIzq() == null || nodo.getDer() == null){
            aux = nodo.getPadre();
            if (nodo.getIzq() != null && nodo.getDer() == null){                                
                aux.setIzq(nodo.getIzq());
                if (nodo.getIzq() != null){
                    nodo.getIzq().setPadre(aux);
                }                  
                nodo.setIzq(null);                                
            }
            else if (nodo.getIzq() == null){                
                aux.setDer(nodo.getDer());
                if (nodo.getDer() != null){
                    nodo.getDer().setPadre(aux);
                }                
                nodo.setDer(null);                                                
            }   
            nodo.setPadre(null);            
            actualizaFe(aux);
        }
        else{                            
            aux = nodo.getDer();                
            while (aux.getIzq() != null){
                aux = aux.getIzq();                
            }
            if (aux == nodo.getDer()){
                nodo.setDer(aux.getDer());
                if (aux.getDer() != null){
                    aux.getDer().setPadre(nodo);
                }                
            }
            else{
                aux.getPadre().setIzq(aux.getDer());
                if (aux.getDer() != null){
                    aux.getDer().setPadre(aux.getPadre());
                }                
            }
            aux.setPadre(null);
            aux.setDer(null);
            nodo.setElem(aux.getElem());            
            cont--;  
            actualizaFe(nodo);             
        }        
    }
    
    public static void main(String[] args) {
        AVLTree<Integer> este = new AVLTree(new NodoBin(null));
        
        
        este.inserta(100);
        este.inserta(50);
        este.inserta(75);        
        este.inserta(25);        
        este.inserta(37);        
        este.inserta(12);               
        este.inserta(40);
        este.inserta(60);
        este.inserta(80);       
        este.inserta(72);
        este.inserta(73);          
        este.inserta(110);
        este.inserta(30);        
        este.eliminaR(80);        
        este.eliminaR(100);
        System.out.println(este.postOrden());        
        este.eliminaR(75);                 
        System.out.println(este.postOrden());
        System.out.println(este.nivelOrden());        
    }
}
