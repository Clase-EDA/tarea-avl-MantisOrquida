/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package árbol;

import java.util.ArrayList;

/**
 *
 * @author 165473
 * @param <T>
 */
public class ColaA<T> implements ColaADT<T> {
    private T[] colec;
    private int inicio, fin;
    private final int MAX = 20;

    public ColaA() {
        colec = (T[]) new Object[MAX];
        inicio = -1;
        fin = -1;
    }
    
    @Override
    public boolean estáVacía(){
        return inicio == -1;
    }
    
    @Override
    public T conPrim(){
        if (estáVacía())
            throw new ExceptionVacía("Cola vacía.");
        return colec[inicio];
    }
    @Override
    public void agrega(T dato){
        if ((fin == colec.length-1 && inicio == 0) || fin == inicio-1)
            expande();
        fin = (fin+1) % colec.length;
        colec[fin] = dato;
        if (inicio == -1)
            inicio = 0;
    }
    
    private void expande(){
        T[] nuevo = (T[]) new Object[colec.length*2];
        int i,j = 0;
        for (i = inicio; i < colec.length; i++){
            nuevo[j] = colec[i];
            j++;
        }
        for (i = 0; i < inicio; i++){
            nuevo[j] = colec[i];
            j++;
        }
        colec = nuevo;
        inicio = 0;
        fin = j-1;
    }
    
    @Override
    public T elimina(){
        if (estáVacía())
            throw new ExceptionVacía("Cola vacía.");
        T res;
        res = colec[inicio];
        colec[inicio] = null;
        if (inicio != fin)
            inicio = (inicio+1) % colec.length;
        else {
            inicio = -1;
            fin = -1;
        }
        return res;
    }
    
    @Override
    public ArrayList<T> multiQuita(int n){
        ArrayList<T> quitados = new ArrayList();
        T t;
        while (!estáVacía() && n > 0){
            n--;
            t = elimina();
            quitados.add(t);            
        }
        return quitados;
    }
    
    @Override
    public T consultaUltimo(){
        if (estáVacía()){
            throw new ExceptionVacía("Cola vacía.");
        }
        else
            return colec[fin];
    }
    @Override
    public int cuentaElementos(){
        int j;
        if (inicio <= fin){
            j = inicio - fin + 1;
        }
        else{
            j = colec.length - fin + inicio + 1;
        }
        return j;
    }
    
    public boolean noHayVecinosIguales(){        
        if (inicio == fin)
            return true;
        boolean resp = true;
        int i = inicio;
        if (inicio < fin){            
            while (i < fin && resp){
                resp = !colec[i].equals(colec[i+1]);
                i++;
            }                   
        } 
        else{
            while (i < colec.length-1 && resp){
                resp = !colec[i].equals(colec[i+1]);
                i++;
            }    
            if (resp){
                resp = !colec[colec.length-1].equals(colec[0]);
            }
            i = 0;
            while (i < fin && resp){
                resp = !colec[i].equals(colec[i+1]);
                i++;
            } 
        }
        return resp;
    }
}